OwnArtifacts Resource Pack v1.5.0 — Chests Pack Models Edition
Target: Minecraft Java 1.21.11

Nové:
- crate a key modely sú založené na 3D modeloch z používateľom dodaného Chests Packu
- Vote = green/normal chest
- Armor = blue/medium chest
- Stroje = orange/machine chest
- Artifact = purple/gold varianta premium modelu
- Weapon = red/dark varianta premium modelu
- OwnArtifacts a GOLD varianty zostali zachované
- rovnaké CustomModelData, plugin OwnCrates netreba meniť

CMD:
Crates on PAPER: 9301 Vote, 9302 Armor, 9303 Stroje, 9304 Artifact, 9305 Weapon
Keys: 9401 Vote, 9402 Armor, 9403 Stroje, 9404 Artifact, 9405 Weapon

Poznámka:
Model JSON uvádzal kredit 'Made with Blockbench'. Súbor bol dodaný používateľom
a tu bol technicky upravený pre KralovnaPack.



=== v1.7.0 — 3D Tools by Mickey Joe merge ===
Trusty Tools bol odstránený. Namiesto neho bol pridaný používateľom dodaný pack
"3D Tools by Mickey Joe".

Obsahuje 3D varianty nástrojov a zbraní, vrátane viacerých stavov/modelov
pre swordy, axe, pickaxe, shovel, hoe, bow, crossbow, mace, trident,
brush, fishing rod a ďalšie itemy obsiahnuté v pôvodnom packu.

Kredit z pôvodného pack.mcmeta:
by Mickey Joe
YT.com/@MushirMickeyJoe

Naše Kralovna / OwnCrates / OwnArtifacts assety a CMD mapovanie zostali zachované.


=== v1.8.0 — XP Crate conversion ===
- former Weapon Crate slot was replaced by XP Crate
- Crate CMD 9305 = XP Crate
- Key CMD 9405 = XP Key
- XP crate/key use emerald + lime + gold visuals
- old OwnCrates weapon_crate/weapon_key model assets were removed
- Mickey Joe weapon/tool item models stay untouched
